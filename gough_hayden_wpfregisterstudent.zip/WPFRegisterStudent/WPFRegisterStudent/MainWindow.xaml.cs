﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace WPFRegisterStudent
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Course> registeredCourses = new List<Course>();

        Course choice;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Course course1 = new Course("IT 145");
            Course course2 = new Course("IT 200");
            Course course3 = new Course("IT 201");
            Course course4 = new Course("IT 270");
            Course course5 = new Course("IT 315");
            Course course6 = new Course("IT 328");
            Course course7 = new Course("IT 330");

            this.comboBox.Items.Add(course1);
            this.comboBox.Items.Add(course2);
            this.comboBox.Items.Add(course3);
            this.comboBox.Items.Add(course4);
            this.comboBox.Items.Add(course5);
            this.comboBox.Items.Add(course6);
            this.comboBox.Items.Add(course7);

            // Initialize UI elements
            this.messageLabel.Content = "";
            this.listBox.Items.Clear();
            this.textBox.Text = "0";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            choice = (Course)(this.comboBox.SelectedItem);

            if (choice == null)
            {
                messageLabel.Content = "Please select a course before registering.";
                return;
            }

            int totalCreditHours = registeredCourses.Count * 3;

            bool isAlreadyRegistered = registeredCourses.Any(c => c.getName() == choice.getName());
            bool hasReachedMaxCredits = (totalCreditHours + 3) > 9;

            if (isAlreadyRegistered)
            {
                messageLabel.Content = $"You are already registered for {choice.getName()}.";
            }
            else if (hasReachedMaxCredits)
            {
                messageLabel.Content = "You cannot register for more than 9 credit hours.";
            }
            else
            {
                choice.SetToRegistered();
                registeredCourses.Add(choice);
                totalCreditHours += 3;

                messageLabel.Content = $"Registration Confirmed for course {choice.getName()}.";

                // Update registered courses list display (ListBox)
                listBox.Items.Clear();
                foreach (Course c in registeredCourses)
                {
                    listBox.Items.Add(c.getName());
                }

                // Update total credit hours display (TextBox)
                textBox.Text = totalCreditHours.ToString();
            }
        }
    }
}
